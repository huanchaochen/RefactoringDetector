package xquery.range;


import xquery.TestRunner;

public class RunTests extends TestRunner {

    @Override
    protected String getDirectory() {
        return "extensions/indexes/range/test/src/xquery";
    }
}
